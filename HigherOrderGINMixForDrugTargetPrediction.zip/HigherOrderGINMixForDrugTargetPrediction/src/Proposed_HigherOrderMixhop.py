import time,sys
from datetime import datetime
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils import data
from torch_sparse import spmm
import scipy.sparse as sp
from sklearn.metrics import roc_auc_score, average_precision_score
import numpy as np
import pandas as pd
from tqdm import tqdm
from tdc.multi_pred import DTI
from loguru import logger

from Util_Proposed import compute_class_metrics , write_csv,check_dir, save_model
import os
from seed_setting_for_reproducibility import seed_torch
class SparseNGCNLayer(nn.Module):
    """
    Multi-scale Sparse Feature Matrix GCN layer.
    :param in_channels: Number of input features.
    :param out_channels: Number of output features.
    :param iterations: Adjacency matrix power order.
    :param dropout_rate: Dropout rate.
    :param device: Device to run computations on.
    """
    def __init__(self, in_channels, out_channels, iterations, dropout_rate, device):
        super(SparseNGCNLayer, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.iterations = iterations
        self.dropout_rate = dropout_rate
        self.device = device
        self.define_parameters()
        self.init_parameters()

    def define_parameters(self):
        """Define the weight matrices."""
        self.weight_matrix = nn.Parameter(torch.Tensor(self.in_channels, self.out_channels)).to(self.device)
        self.bias = nn.Parameter(torch.Tensor(1, self.out_channels)).to(self.device)

    def init_parameters(self):
        """Initialize weights using Xavier initialization."""
        torch.nn.init.xavier_uniform_(self.weight_matrix)
        torch.nn.init.xavier_uniform_(self.bias)

    def forward(self, normalized_adjacency_matrix, features):
        """Forward pass."""
        feature_count, _ = torch.max(features["indices"], dim=1)
        feature_count = feature_count + 1
        base_features = spmm(features["indices"], features["values"], feature_count[0],
                             feature_count[1], self.weight_matrix)
        base_features = base_features + self.bias
        base_features = F.dropout(base_features, p=self.dropout_rate, training=self.training)
        base_features = F.relu(base_features)
        for _ in range(self.iterations - 1):
            base_features = spmm(normalized_adjacency_matrix["indices"],
                                 normalized_adjacency_matrix["values"],
                                 base_features.shape[0],
                                 base_features.shape[0],
                                 base_features)
        return base_features

    def __repr__(self):
        return f"{self.__class__.__name__} ({self.in_channels} -> {self.out_channels})"

class GINLayer(nn.Module):
    """
    Graph Isomorphic Network (GIN) Layer.
    :param in_channels: Number of input features.
    :param out_channels: Number of output features.
    :param epsilon: Small constant for central node feature scaling.
    :param dropout_rate: Dropout rate.
    :param device: Device to run computations on.
    """
    def __init__(self, in_channels, out_channels, epsilon=0.0, dropout_rate=0.5, device='cpu'):
        super(GINLayer, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.epsilon = epsilon
        self.dropout_rate = dropout_rate
        self.device = device
        self.mlp = nn.Sequential(
            nn.Linear(in_channels, out_channels),
            nn.ReLU(),
            nn.Linear(out_channels, out_channels))
        self.dropout = nn.Dropout(dropout_rate)
        self.init_parameters()

    def init_parameters(self):
        """Initialize MLP weights using Xavier initialization."""
        for layer in self.mlp:
            if isinstance(layer, nn.Linear):
                torch.nn.init.xavier_uniform_(layer.weight)
                torch.nn.init.zeros_(layer.bias)

    def forward(self, normalized_adjacency_matrix, features):
        """Forward pass."""
        neighbor_features = spmm(normalized_adjacency_matrix["indices"],
                                 normalized_adjacency_matrix["values"],
                                 features.shape[0],
                                 features.shape[0],
                                 features)
        combined_features = (1 + self.epsilon) * features + neighbor_features
        transformed_features = self.mlp(combined_features)
        transformed_features = self.dropout(transformed_features)
        return transformed_features

    def __repr__(self):
        return f"{self.__class__.__name__} ({self.in_channels} -> {self.out_channels})"

def compute_second_order_adj(normalized_adjacency_matrix):
    """Compute the second-order adjacency matrix."""
    indices = normalized_adjacency_matrix["indices"]
    values = normalized_adjacency_matrix["values"]
    num_nodes = values.shape[0]
    first_order_adj = torch.sparse_coo_tensor(indices, values, (num_nodes, num_nodes))
    second_order_adj = torch.sparse.mm(first_order_adj, first_order_adj)
    return {"indices": second_order_adj.indices(), "values": second_order_adj.values()}

class HigherOrderGINLayer(nn.Module):
    """
    Higher-Order Graph Isomorphic Network (GIN) Layer.
    :param in_channels: Number of input features.
    :param out_channels: Number of output features.
    :param epsilon: Small constant for central node feature scaling.
    :param dropout_rate: Dropout rate.
    :param device: Device to run computations on.
    """
    def __init__(self, in_channels, out_channels, epsilon=0.0, dropout_rate=0.5, device='cpu'):
        super(HigherOrderGINLayer, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.epsilon = epsilon
        self.dropout_rate = dropout_rate
        self.device = device
        self.mlp = nn.Sequential(
            nn.Linear(out_channels, out_channels),
            nn.ReLU(),
            nn.Linear(out_channels, out_channels))
        self.edge_mlp = nn.Sequential(
            nn.Linear(out_channels, out_channels),
            nn.ReLU(),
            nn.Linear(out_channels, out_channels))
        self.second_order_mlp = nn.Sequential(
            nn.Linear(out_channels, out_channels),
            nn.ReLU(),
            nn.Linear(out_channels, out_channels))
        self.feature_transform = nn.Linear(in_channels, out_channels)
        self.dropout = nn.Dropout(dropout_rate)
        self.init_parameters()

    def init_parameters(self):
        """Initialize MLP weights using Xavier initialization."""
        for layer in list(self.mlp) + list(self.edge_mlp) + list(self.second_order_mlp):
            if isinstance(layer, nn.Linear):
                torch.nn.init.xavier_uniform_(layer.weight)
                torch.nn.init.zeros_(layer.bias)

    def forward(self, normalized_adjacency_matrix, features, edge_features=None, second_order_adj=None):
        """Forward pass."""
        features = self.feature_transform(features)
        first_order_agg = spmm(normalized_adjacency_matrix["indices"],
                               normalized_adjacency_matrix["values"],
                               features.shape[0],
                               features.shape[0],
                               features)
        if edge_features is not None:
            edge_features = self.edge_mlp(edge_features)
            first_order_agg += spmm(normalized_adjacency_matrix["indices"],
                                    normalized_adjacency_matrix["values"],
                                    features.shape[0],
                                    features.shape[0],
                                    edge_features)
        if second_order_adj is not None:
            second_order_agg = spmm(second_order_adj["indices"],
                                    second_order_adj["values"],
                                    features.shape[0],
                                    features.shape[0],
                                    features)
            second_order_agg = self.second_order_mlp(second_order_agg)
        else:
            second_order_agg = torch.zeros_like(first_order_agg)
        combined_features = (1 + self.epsilon) * features + first_order_agg + second_order_agg
        transformed_features = self.mlp(combined_features)
        transformed_features = self.dropout(transformed_features)
        return transformed_features

class HigherOrderMixHop(nn.Module):
    """
    MixHop: Higher-Order Graph Convolutional Architectures.
    :param feature_number: Number of input features.
    :param class_number: Number of target classes.
    :param layers_1: List of layer sizes for the first set of layers.
    :param layers_2: List of layer sizes for the second set of layers.
    :param hidden1: Size of the first hidden layer.
    :param hidden2: Size of the second hidden layer.
    :param dropout: Dropout rate.
    :param device: Device to run computations on.
    """

    def __init__(self, feature_number, class_number=1, layers_1=[32, 32, 32, 32], layers_2=[32, 32, 32, 32], hidden1=64, hidden2=32, dropout=0.1, device=torch.device('cpu')):
        super(HigherOrderMixHop, self).__init__()
        self.layers_1 = layers_1
        self.layers_2 = layers_2
        self.hidden1 = hidden1
        self.hidden2 = hidden2
        self.feature_number = feature_number
        self.class_number = class_number
        self.dropout = dropout
        self.device = device
        self.calculate_layer_sizes()
        self.setup_layer_structure()
        print(f"{self.__class__}print lne {sys._getframe().f_lineno}")

    def calculate_layer_sizes(self):
        """Calculate the sizes of the layers."""
        self.abstract_feature_number_1 = sum(self.layers_1)
        self.abstract_feature_number_2 = sum(self.layers_2)
        self.order_1 = len(self.layers_1)
        self.order_2 = len(self.layers_2)

    def setup_layer_structure(self):
        """Set up the layer structure."""
        self.upper_layers = nn.ModuleList([
            SparseNGCNLayer(self.feature_number, self.layers_1[i - 1], i, self.dropout, self.device) for i in range(1, self.order_1 + 1)])
        self.bottom_layers = nn.ModuleList([
            HigherOrderGINLayer(self.abstract_feature_number_1, self.layers_2[i - 1], 32, self.dropout, self.device) for i in range(1, self.order_2 + 1)])
        self.bilinear = nn.Bilinear(self.abstract_feature_number_2, self.abstract_feature_number_2, self.hidden1)
        self.decoder = nn.Sequential(
            nn.Linear(self.hidden1, self.hidden2),
            nn.ELU(),
            nn.Linear(self.hidden2, 1))

    def latent_representations(self, normalized_adjacency_matrix, features):
        """Generate embeddings."""
        abstract_features_1 = torch.cat([self.upper_layers[i](normalized_adjacency_matrix, features) for i in range(self.order_1)], dim=1)
        abstract_features_1 = F.dropout(abstract_features_1, self.dropout, training=self.training)
        second_order_adj = compute_second_order_adj(normalized_adjacency_matrix)
        abstract_features_2 = torch.cat([self.bottom_layers[i](normalized_adjacency_matrix, abstract_features_1, second_order_adj=second_order_adj) for i in range(self.order_2)], dim=1)
        return F.dropout(abstract_features_2, self.dropout, training=self.training)

    def forward(self, normalized_adjacency_matrix, features, idx):
        """Forward pass."""
        latent_features = self.latent_representations(normalized_adjacency_matrix, features)
        feat_p1 = latent_features[idx[0]]
        feat_p2 = latent_features[idx[1]]
        feat = F.elu(self.bilinear(feat_p1, feat_p2))
        feat = F.dropout(feat, self.dropout, training=self.training)
        predictions = self.decoder(feat)
        return predictions, latent_features

class DataDTI(data.Dataset):
    """Dataset for Drug-Target Interaction (DTI) data."""
    def __init__(self, idx_map, labels, df):
        self.labels = labels
        self.idx_map = idx_map
        self.df = df

    def __len__(self):
        return len(self.df)

    def __getitem__(self, index):
        idx1 = self.idx_map[str(self.df.iloc[index].Drug_ID)]
        idx2 = self.idx_map[self.df.iloc[index].Target_ID]
        y = self.labels[index]
        return y, (idx1, idx2)



def compute_symmetric_normalized_adjacency(A, identity_matrix):
    """
    Computes the symmetric normalized adjacency matrix with self-loops.

    :param A: Sparse adjacency matrix.
    :param identity_matrix: Identity matrix of the same size as A.
    :return: Symmetric normalized adjacency matrix.
    """
    A_tilde = A + 2 * identity_matrix  # Add self-loops
    degrees = np.array(A_tilde.sum(axis=1)).flatten()  # Compute degree matrix
    D_inv_sqrt = sp.diags(np.power(degrees, -0.5, where=degrees > 0))  # Avoid division by zero
    return D_inv_sqrt @ A_tilde @ D_inv_sqrt  # Apply normalization


def generate_sparse_propagation_matrix(A, device):
    """
    Generates a sparse propagation matrix in a format suitable for PyTorch.

    :param A: Sparse adjacency matrix.
    :param device: Target device for tensor storage.
    :return: Dictionary containing sparse propagation matrix indices and values.
    """
    I = sp.eye(A.shape[0], format='csr')  # Create identity matrix
    A_tilde_hat = compute_symmetric_normalized_adjacency(A, I).tocoo()  # Normalize and convert to COO format

    indices = np.vstack((A_tilde_hat.row, A_tilde_hat.col))  # Stack row and column indices
    return {
        "indices": torch.LongTensor(indices).to(device),
        "values": torch.FloatTensor(A_tilde_hat.data).to(device),
    }



def convert_features_to_sparse_tensor(features, device):
    """
    Converts a dense feature matrix into a sparse PyTorch tensor representation.

    :param features: Dense feature matrix (NumPy or SciPy sparse format).
    :param device: Target device for tensor storage (e.g., 'cpu' or 'cuda').
    :return: Dictionary containing sparse indices, values, and shape of the feature matrix.
    """
    row_indices, col_indices = features.nonzero()  # Extract nonzero indices
    values = np.ones(len(row_indices), dtype=np.float32)  # Assign value 1.0 to all nonzero entries

    sparse_matrix = sp.coo_matrix((values, (row_indices, col_indices)), shape=features.shape, dtype=np.float32)
    indices = np.vstack((sparse_matrix.row, sparse_matrix.col))  # Stack row and column indices

    return {
        "indices": torch.LongTensor(indices).to(device),
        "values": torch.FloatTensor(sparse_matrix.data).to(device),
        "dimensions": sparse_matrix.shape,
    }

def evaluate_model_performance(model, data_loader, batch_size, propagation_matrix, features):
    """
    Evaluates the model performance using standard classification metrics.

    :param model: Trained model instance.
    :param data_loader: Data loader containing test samples.
    :param batch_size: Number of samples per batch.
    :param propagation_matrix: Precomputed propagation matrix for graph convolution.
    :param features: Node feature matrix.
    :return: Dictionary containing AUROC, AUPRC, and classification metrics.
    """
    model.eval()
    total_batches = len(data_loader)

    y_true = np.empty((total_batches, batch_size))
    y_pred = np.empty((total_batches, batch_size))

    for i in tqdm(range(total_batches), desc='Evaluating Model'):
        labels, pairs = next(iter(data_loader))  # Fetch batch data
        output, _ = model(propagation_matrix, features, pairs)  # Forward pass

        y_true[i] = labels.numpy()
        y_pred[i] = output.flatten().detach().cpu().numpy()

    # Flatten predictions and labels for evaluation
    y_true = y_true.flatten()
    y_pred = y_pred.flatten()

    # Binary classification thresholding
    y_pred_binary = (y_pred > 0.5).astype(int)

    # Compute evaluation metrics
    auprc = average_precision_score(y_true, y_pred)
    auroc = roc_auc_score(y_true, y_pred)
    classification_results = compute_class_metrics(y_true, y_pred_binary)

    # Store results
    classification_results.update({
        'auprc': auprc,
        'auroc': auroc
    })

    return classification_results




def preprocess_dti_dataset(df: pd.DataFrame, threshold=30.0, oversampling: bool = True) -> pd.DataFrame:
    """
    Preprocess Drug-Target Interaction (DTI) dataset by handling missing values,
    creating binary labels based on threshold, and optionally applying oversampling.

    :param df: Input DataFrame containing DTI data.
    :param oversampling: Boolean flag to enable/disable oversampling of negative samples.
    :return: Processed DataFrame with balanced labels if oversampling is enabled.
    """
    df = df.dropna().copy()  # Drop missing values and create a copy to avoid warnings
    df['Drug_ID'] = df['Drug_ID'].astype(str)

    # Create binary labels based on Y threshold
    df['Label'] = (df['Y'] > threshold).astype(int)  # 1 if Y > 30, else 0 # this is for Davice dataset for binding DB:  7.6 and 12.1 for KIBA
    #df['Label'] = (df['Y'] > 7).astype(int) #The same was used by MINDG

    # Count positive and negative samples
    neg_samples = df[df['Label'] == 0]
    pos_samples = df[df['Label'] == 1]
    neg_label_num, pos_label_num = len(neg_samples), len(pos_samples)

    # Log sample distribution
    pos_percentage = pos_label_num * 100 / (neg_label_num + pos_label_num)
    logger.info(f'Negative samples: {neg_label_num}, Positive samples: {pos_label_num}, ({pos_percentage:.2f}%)')

    # Apply oversampling if enabled
    if oversampling and neg_label_num < pos_label_num:
        logger.info('Applying oversampling to balance classes...')
        oversampled_neg = pd.concat([neg_samples] * (pos_label_num // neg_label_num), ignore_index=True)
        df = pd.concat([df, oversampled_neg], ignore_index=True)

        # Log updated sample distribution
        neg_label_num, pos_label_num = df['Label'].value_counts().sort_index().tolist()
        pos_percentage = pos_label_num * 100 / (neg_label_num + pos_label_num)
        logger.info(f'After oversampling - Negative samples: {neg_label_num}, Positive samples: {pos_label_num}, ({pos_percentage:.2f}%)')

    return df



def train_model(dataset_name, device=torch.device('cpu'),binarizeThreshold=30):
    """Train the HigherOrderMixHop model for Drug-Target Interaction (DTI) prediction.

    Args:
        dataset_name (str): Name of the dataset (e.g., 'DAVIS').
        device (torch.device): Device to run the training on (e.g., 'cpu' or 'cuda').
    """
    # Hyperparameters
    batch_size = 32
    num_epochs = 20
    learning_rate = 5e-4
    early_stopping_patience = 10

    # Paths for saving results, logs, and models
    results_base_path = "../results/"
    current_time = datetime.now().strftime("%m-%d-%H-%M")
    experiment_path = f"{results_base_path}output_proposed/{dataset_name}/{current_time}/"
    csv_output_path = f"{results_base_path}output_proposed/{dataset_name}/"
    model_save_path = f"{results_base_path}output/model/"
    log_file_path = f"{experiment_path}/train.log"

    # Create directories if they don't exist
    check_dir(experiment_path)
    check_dir(csv_output_path)
    check_dir(model_save_path)
    log_fd = logger.add(log_file_path)

    # Load and preprocess the dataset
    dti_data = DTI(name=dataset_name)
    dataset_split = dti_data.get_split(method='random', seed=42)
    processed_data = preprocess_dti_dataset(dataset_split['train'],threshold=binarizeThreshold) #because 30 is well known
    logger.info(f"Dataset: {dataset_name}\n{processed_data}")

    # Create mappings for drugs and targets
    unique_entities = processed_data['Drug_ID'].tolist() + processed_data['Target_ID'].tolist()
    unique_entities = list(set(unique_entities))
    entity_to_index = {entity: idx for idx, entity in enumerate(unique_entities)}

    # Create sparse feature matrix (one-hot encoding)
    num_entities = len(unique_entities)
    feature_matrix = np.eye(num_entities)
    sparse_feature_matrix = convert_features_to_sparse_tensor(feature_matrix, device)

    # Create adjacency matrix for the graph
    edges = processed_data[['Drug_ID', 'Target_ID']].values
    edge_indices = np.array(list(map(entity_to_index.get, edges.flatten()))).reshape(edges.shape)
    adjacency_matrix = sp.coo_matrix((np.ones(edge_indices.shape[0]), (edge_indices[:, 0], edge_indices[:, 1])),
                                     shape=(num_entities, num_entities), dtype=np.float32)
    adjacency_matrix = adjacency_matrix + adjacency_matrix.T.multiply(adjacency_matrix.T > adjacency_matrix) - adjacency_matrix.multiply(adjacency_matrix.T > adjacency_matrix)
    propagation_matrix = generate_sparse_propagation_matrix(adjacency_matrix, device)

    # Split dataset into train, validation, and test sets
    dataset_split = dti_data.get_split(method='random', seed=42, frac=[0.7, 0.1, 0.2])
    train_data = preprocess_dti_dataset(dataset_split['train'])
    val_data = preprocess_dti_dataset(dataset_split['valid'])
    test_data = preprocess_dti_dataset(dataset_split['test'])

    # Create data loaders
    train_loader = data.DataLoader(DataDTI(entity_to_index, train_data.Label.values, train_data),
                                   batch_size=batch_size, shuffle=True, drop_last=True)
    val_loader = data.DataLoader(DataDTI(entity_to_index, val_data.Label.values, val_data),
                                 batch_size=batch_size, shuffle=False, drop_last=True)
    test_loader = data.DataLoader(DataDTI(entity_to_index, test_data.Label.values, test_data),
                                  batch_size=batch_size, shuffle=False, drop_last=True)

    # Initialize model and optimizer
    num_features = sparse_feature_matrix["dimensions"][1]
    model = HigherOrderMixHop(num_features).to(device)
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    # Training loop
    max_validation_auc = 0
    no_improvement_counter = 0
    start_time = time.time()
    logger.info('Starting training...')

    for epoch in range(num_epochs):
        model.train()
        epoch_start_time = time.time()
        epoch_loss = 0
        train_predictions = []
        train_labels = []

        for batch_idx, (labels, pairs) in enumerate(tqdm(train_loader, desc=f"Epoch {epoch + 1}")):
            labels = labels.to(device)
            optimizer.zero_grad()
            predictions, _ = model(propagation_matrix, sparse_feature_matrix, pairs)
            loss = F.binary_cross_entropy_with_logits(predictions.squeeze(), labels.float())
            loss.backward()
            optimizer.step()

            epoch_loss += loss.item()
            train_predictions.extend(predictions.detach().cpu().numpy().flatten())
            train_labels.extend(labels.cpu().numpy().flatten())

            # Log batch loss
            write_csv(f"{csv_output_path}proposedMixhopHIORDER_loss.csv",
                       {'epoch': epoch, 'batch': batch_idx, 'loss': loss.item(), 'avg_loss': epoch_loss / (batch_idx + 1)})

        # Calculate training metrics
        train_auc = roc_auc_score(train_labels, train_predictions)
        logger.info(f"Epoch {epoch + 1}: Training AUC = {train_auc:.4f}, Loss = {epoch_loss / len(train_loader):.4f}")

        # Evaluate on validation set
        validation_metrics = evaluate_model_performance(model, val_loader, batch_size, propagation_matrix, sparse_feature_matrix)
        validation_metrics['epoch'] = epoch
        validation_metrics['epoch_loss'] = epoch_loss / len(train_loader)
        write_csv(f"{csv_output_path}proposedMixhopHIORDER_val_metrics.csv", validation_metrics)
        logger.info(f"Validation Metrics: {validation_metrics}")

        # Early stopping
        if validation_metrics['auroc'] > max_validation_auc:
            max_validation_auc = validation_metrics['auroc']
            no_improvement_counter = 0
        else:
            no_improvement_counter += 1
            if no_improvement_counter == early_stopping_patience:
                logger.info(f"Early stopping at epoch {epoch + 1} due to no improvement in validation AUC.")
                break

        logger.info(f"Epoch {epoch + 1} completed in {time.time() - epoch_start_time:.2f}s")

    # Save the trained model
    model_save_name = f"proposedMixhopHIORDER_{dataset_name}_epoch{num_epochs}.pt"
    save_model(model, f"{model_save_path}{model_save_name}")
    logger.info(f"Model saved to {model_save_path}{model_save_name}")

    # Evaluate on test set
    test_metrics = evaluate_model_performance(model, test_loader, batch_size, propagation_matrix, sparse_feature_matrix)
    write_csv(f"{csv_output_path}proposed_mixhopHIORDER_{dataset_name}_test_metrics.csv", test_metrics)
    logger.info(f"Test Metrics: {test_metrics}")

    # Clean up logging
    logger.remove(log_fd)
    logger.info(f"Total training time: {time.time() - start_time:.2f}s")




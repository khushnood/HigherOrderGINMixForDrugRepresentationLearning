from Proposed_HigherOrderMixhop import train_model
from seed_setting_for_reproducibility import seed_torch
import torch
if __name__ == '__main__':
    numperOfExperiments = 5
    for i in range(numperOfExperiments):
        seed_torch(42+numperOfExperiments)
        train_model('DAVIS',torch.device('cpu'),binarizeThreshold=30)
        print(f"Iteration {i + 1} completed")

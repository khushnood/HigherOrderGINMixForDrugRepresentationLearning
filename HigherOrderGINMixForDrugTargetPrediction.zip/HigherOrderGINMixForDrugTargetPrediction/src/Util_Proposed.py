import csv
import os
import random

import torch
import scipy.sparse as sp

import numpy as np

from loguru import logger
from sklearn.metrics import mean_squared_error, roc_auc_score, average_precision_score, f1_score, log_loss
from lifelines.utils import concordance_index
from scipy.stats import pearsonr

from datetime import datetime
import pandas as pd
from tqdm import tqdm
neg_label = 1
pos_label = 0
def compute_class_metrics(y_label, y_pred, pos_label=1, neg_label=0):
    """
    Compute classification metrics such as sensitivity, specificity, precision, recall, accuracy, and F1 score.

    Args:
        y_label (list or array): True labels.
        y_pred (list or array): Predicted labels.
        pos_label (int, optional): The positive label class. Default is 1.
        neg_label (int, optional): The negative label class. Default is 0.

    Returns:
        dict: A dictionary containing the computed metrics.
    """
    # Initialize counts for confusion matrix
    TP = FP = TN = FN = 0

    # Compute confusion matrix values
    for true, pred in zip(y_label, y_pred):
        if pred == pos_label:
            if true == pos_label:
                TP += 1  # True Positive
            else:
                FP += 1  # False Positive
        else:
            if true == neg_label:
                TN += 1  # True Negative
            else:
                FN += 1  # False Negative

    # Log confusion matrix
    logger.info(f"Confusion Matrix: TP={TP}, TN={TN}, FP={FP}, FN={FN}")

    # Compute metrics with checks to avoid division by zero
    sensitivity = TP / (TP + FN) if (TP + FN) > 0 else 1.0
    specificity = TN / (FP + TN) if (FP + TN) > 0 else 1.0
    recall = sensitivity  # Recall is same as sensitivity
    precision = TP / (TP + FP) if (TP + FP) > 0 else 1.0
    accuracy = (TP + TN) / (TP + TN + FP + FN)
    f1 = 2 * TP / (2 * TP + FN + FP) if (2 * TP + FN + FP) > 0 else 1.0

    # Return the calculated metrics
    return {
        "sensitivity": sensitivity,
        "specificity": specificity,
        "recall": recall,
        "precision": precision,
        "accuracy": accuracy,
        "f1": f1
    }


def write_csv(file_path, result):
    """Record results to a CSV file."""
    file_exists = pd.io.common.file_exists(file_path)
    timestamp = datetime.now().strftime("%m-%d-%H-%M")
    result_df = pd.DataFrame([result])
    result_df['timestamp'] = timestamp
    if file_exists:
        result_df.to_csv(file_path, mode='a', header=False, index=False)
    else:
        result_df.to_csv(file_path, mode='w', header=True, index=False)

def check_dir(path):
    if not os.path.exists(path):
        os.makedirs(path)
        logger.info(f"create dir: {path}")
    else:
        logger.info(f"dir exists, {path}")

def save_model(model, path):
    torch.save(model.state_dict(),path)
    logger.info(f"save {path} model parameters done")

def load_model(model, path):
    if os.path.exists(path):
        model.load_state_dict(torch.load(path))
        model.eval()
        logger.info(f"load {path} model parameters done")

